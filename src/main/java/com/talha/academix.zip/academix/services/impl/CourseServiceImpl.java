package com.talha.academix.services.impl;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.talha.academix.dto.CourseDTO;
import com.talha.academix.enums.ActivityAction;
import com.talha.academix.enums.CourseCatagory;
import com.talha.academix.enums.CourseState;
import com.talha.academix.exception.ResourceNotFoundException;
import com.talha.academix.exception.RoleMismatchException;
import com.talha.academix.model.Course;
import com.talha.academix.model.User;
import com.talha.academix.repository.CourseRepo;
import com.talha.academix.services.ActivityLogService;
import com.talha.academix.services.CourseService;
import com.talha.academix.services.UserService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CourseServiceImpl implements CourseService {

    private final CourseRepo courseRepo;
    private final ModelMapper mapper;
    private final UserService userService;
    private final ActivityLogService activityLogService;

    /*----------------------------------- View Methods ----------------------------------- */

    @Override
    public CourseDTO getCourseById(Long id) {
        Course course = courseRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + id));
        return mapper.map(course, CourseDTO.class);
    }

    @Override
    public List<CourseDTO> getCourseByCatagory(CourseCatagory catagory) {
        List<Course> courses = courseRepo.findAllByCatagory(catagory);
        return courses.stream()
                .map(course -> mapper.map(course, CourseDTO.class))
                .toList();
    }

    @Override
    public List<CourseDTO> getAllCourses() {
        List<Course> courses = courseRepo.findAll();
        return courses.stream()
                .map(course -> mapper.map(course, CourseDTO.class))
                .toList();
    }

    @Override
    public List<CourseDTO> getAllCoursesByTeacher(Long teacherId) {
        List<Course> courses = courseRepo.findAllByTeacherid(teacherId);
        return courses.stream()
                .map(course -> mapper.map(course, CourseDTO.class))
                .toList();
    }

    @Override
    public List<CourseDTO> getAllCoursesByState(CourseState state) {
        List<Course> courses = courseRepo.findAllBystate(state);
        return courses.stream()
                .map(course -> mapper.map(course, CourseDTO.class))
                .toList();
    }

    /*----------------------------------- Action Methods ----------------------------------- */

    @Override
    public CourseDTO createCourseByTeacher(Long userid, CourseDTO dto) {
        if (userService.teacherValidation(userid)) {
            return createCourse(dto);
        } else
            throw new RoleMismatchException("Only Teacher can create course");
    }
    
    @Override
    public CourseDTO updateCourseByAdmin(Long userid, Long courseId, CourseDTO dto) {
        if (userService.adminValidation(userid)) {
            return updateCourse(courseId, dto);
        } else
            throw new RoleMismatchException("Only Admin can update course");
    }

    @Override
    public void deleteCourseByTeacher(Long userid, Long courseId) {
        Boolean owned = teacherOwnership(userid, courseId);
        if (owned) {
            Course course = courseRepo.findById(courseId)
                    .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + courseId));
            deleteCourse(courseId);
            activityLogService.logAction(userid, ActivityAction.COURSE_DELETION, null);
        } else
            throw new RoleMismatchException("Only Teacher can delete course");
    }

    @Override
    public void deleteCourseByAdmin(Long userid, Long courseId) {
        if (userService.adminValidation(userid)) {
            deleteCourse(courseId);
        } else
            throw new RoleMismatchException("Only Admin can delete course");
    }

    @Override
    public Boolean courseRejection(User admin, Long courseId) {

        Course course = courseRepo.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));

        if (!userService.adminValidation(admin.getUserid())) {
            throw new RoleMismatchException("Only Admin can reject course");
        }
        if (course.getState() != CourseState.DRAFT) {
            throw new IllegalArgumentException("Only courses in DRAFT state can be rejected");
        }
        course.setState(CourseState.REJECTED);
        courseRepo.save(course);
        activityLogService.logAction(
                admin.getUserid(),
                ActivityAction.COURSE_REJECTED,
                course.getCoursename() + " of " + course.getTeacher().getUsername() + " has been rejected. ID = "
                        + courseId);
        return true;
    }

    @Override
    public Boolean courseApproval(User admin, Long courseId) {
        Course course = courseRepo.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));

        if (!userService.adminValidation(admin.getUserid())) {
            throw new RoleMismatchException("Only Admin can approve course");
        }

        if (course.getState() == CourseState.DRAFT || course.getState() == CourseState.MODIFIED) {
            course.setState(CourseState.APPROVED);
            courseRepo.save(course);

            activityLogService.logAction(
                    admin.getUserid(),
                    ActivityAction.COURSE_APPROVED,
                    course.getCoursename() + " of " + course.getTeacher().getUsername() + " has been approved. ID = "
                            + courseId);
            return true;
        } else {
            throw new IllegalArgumentException("Only DRAFTED or MODIFIED courses can be approved");
        }
    }

    @Override
    public CourseDTO courseModification(User teacher, Long courseId, CourseDTO dto) {
        Course course = courseRepo.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));

        Boolean owned = teacherOwnership(teacher.getUserid(), courseId);

        if (owned && (course.getState() == CourseState.DISABLED || course.getState() == CourseState.IN_DEVELOPMENT
                || course.getState() == CourseState.REJECTED)) {

            CourseDTO updated = updateCourse(courseId, dto);

            activityLogService.logAction(teacher.getUserid(), ActivityAction.COURSE_MODIFIED, null);
            return updated;
        } else
            throw new IllegalArgumentException("Only courses in DRAFT, MODIFIED or REJECTED state can be modified");
    }

    @Override
    public Boolean courseDevelopment(User Teacher, Long courseId) {
        Course course = courseRepo.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));

        Boolean owned = teacherOwnership(Teacher.getUserid(), courseId);

        if (owned && course.getState() == CourseState.APPROVED) {
            course.setState(CourseState.IN_DEVELOPMENT);
            courseRepo.save(course);

            activityLogService.logAction(Teacher.getUserid(), ActivityAction.COURSE_IN_DEVELOPMENT, null);
            return true;
        } else {
            throw new IllegalArgumentException("Only approved courses can be moved to IN_DEVELOPMENT state");
        }
    }

    @Override
    public Boolean courseLaunch(User Teacher, Long courseId) {
        Course course = courseRepo.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        Boolean owned = teacherOwnership(Teacher.getUserid(), courseId);
        if (owned && course.getState() == CourseState.IN_DEVELOPMENT) {
            course.setState(CourseState.LAUNCHED);
            courseRepo.save(course);

            activityLogService.logAction(Teacher.getUserid(), ActivityAction.COURSE_LAUNCHED, null);
            return true;
        } else {
            throw new IllegalArgumentException("Only courses in IN_DEVELOPMENT state can be launched");
        }
    }

    @Override
    public CourseDTO courseDisable(User admin, Long courseId) {
        if (!userService.adminValidation(admin.getUserid())) {
            throw new RoleMismatchException("Only Admin can disable course");
        }
        Course course = courseRepo.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));

        if (course.getState() == CourseState.LAUNCHED) {
            course.setState(CourseState.DISABLED);
            courseRepo.save(course);

            activityLogService.logAction(
                    admin.getUserid(),
                    ActivityAction.COURSE_DISABLED,
                    course.getCoursename() + " of " + course.getTeacher().getUsername() + " has been disabled. ID = "
                            + courseId);
            return mapper.map(course, CourseDTO.class);
        } else {
            throw new IllegalArgumentException("Only launched courses can be disabled");
        }
    }

    /*----------------------------------- Inner Methods ----------------------------------- */

    @Override
    public CourseDTO createCourse(CourseDTO dto) {
        if (courseRepo.findCourseByCoursenameAndTeacherid(dto.getCoursename(), dto.getTeacherid()) == null) {
            Course course = mapper.map(dto, Course.class);
            course.setState(CourseState.DRAFT);
            course = courseRepo.save(course);

            activityLogService.logAction(dto.getTeacherid(), ActivityAction.COURSE_DRAFTED, null);

            return mapper.map(course, CourseDTO.class);
        } else
            throw new IllegalArgumentException("Teacher already have a course with name: " + dto.getCoursename());
    }

    @Override
    public CourseDTO updateCourse(Long courseId, CourseDTO dto) {
        Course existing = courseRepo.findById(courseId)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + courseId));
        existing.setCoursename(dto.getCoursename());
        existing.setDuration(dto.getDuration());
        existing.setFees(dto.getFees());
        existing.setCatagory(dto.getCatagory());
        existing.setState(CourseState.MODIFIED);
        existing = courseRepo.save(existing);
        return mapper.map(existing, CourseDTO.class);
    }

    @Override
    public void deleteCourse(Long id) {
        Course course = courseRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + id));
        courseRepo.delete(course);
    }

    @Override
    public boolean teacherValidation(Long userid, Long courseId) {
        if (courseRepo.findByCourseIdAndTeacherId(userid, courseId) != null) {
            return true;
        } else
            return false;
    }

    private boolean teacherOwnership(Long userid, Long courseId) {
        Course course = courseRepo.findById(courseId)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + courseId));
        if (course.getTeacher().getUserid().equals(userid)) {
            return true;
        } else {
            throw new RoleMismatchException("Only the Teacher who owned the course can modify it");
        }
    }
}
