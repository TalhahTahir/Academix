package com.talha.academix.enums;

public enum EnrollmentStatus {
    IN_PROGRESS,
    COMPLETED,
}
