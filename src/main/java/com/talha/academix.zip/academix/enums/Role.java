package com.talha.academix.enums;

public enum Role {
    ADMIN,
    TEACHER,
    STUDENT
}
