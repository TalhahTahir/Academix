package com.talha.academix.enums;

public enum PaymentMedium {
    JAZZCASH,
    STRIPE,
    EASYPAYSA,
    PAYPAL,
    BANK_ACCOUNT
}
