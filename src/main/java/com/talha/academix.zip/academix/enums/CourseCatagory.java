package com.talha.academix.enums;

public enum CourseCatagory {
    PROGRAMMING,
    BUSINESS,
    ARTS,
    SCIENCE,
    ENGINEERING,
    MEDICAL,
    LINGUISTICS,
    PERSONAL_DEVELOPMENT
}
