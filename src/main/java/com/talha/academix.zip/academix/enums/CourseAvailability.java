package com.talha.academix.enums;

public enum CourseAvailability {
    LAUNCHED,
    COMMING_SOON
}
