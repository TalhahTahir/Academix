package com.talha.academix.enums;

public enum PaymentType {
    INCOMING, // e.g. student fees
    OUTGOING  // e.g. teacher salaries
}
