package com.talha.academix.enums;

public enum CourseState {
    DRAFT,
    PENDING_APPROVAL,
    APPROVED,
    IN_DEVELOPMENT,
    LAUNCHED
}
