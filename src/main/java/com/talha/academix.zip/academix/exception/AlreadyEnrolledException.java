package com.talha.academix.exception;

public class AlreadyEnrolledException extends RuntimeException{
    public AlreadyEnrolledException(String message) {
        super(message);
        }

}
