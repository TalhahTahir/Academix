package com.talha.academix.enums;

public enum ProgressStatus {
    IN_PROGRESS,
    COMPLETED
}
