package com.talha.academix.exception;

public class RoleMismatchException extends RuntimeException {
     public RoleMismatchException(String message) {
        super(message);
        }
}
